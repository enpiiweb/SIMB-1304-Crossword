<?php


// phpBB 2.x auto-generated config file
// Do not change anything in this file!

$dbms = 'mysql4';

$dbhost = 'localhost';
$dbname = 'np_crossword_deef';
$dbuser = 'root';
$dbpasswd = '';

$table_prefix = 'phpbb_';

define('PHPBB_INSTALLED', true);

?>